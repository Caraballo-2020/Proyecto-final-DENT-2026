﻿using Iot.Device.Ssd13xx;
using nanoFramework.Hardware.Esp32;
using System;
using System.Device.Adc;
using System.Device.Gpio;
using System.Device.I2c;
using System.Threading;

namespace PROYECTO_FINAL_VTest.Hardware
{
    internal class Oled_bateria
    {
        private AdcController _adc;
        private AdcChannel _adcChannel;
        private Ssd1306 _oled;


        private int _adcPin;
        private string _lastVoltsText = "";
        private string _lastBatText = "";
        private GpioController LED_LowBatteryController = new GpioController();

        public Oled_bateria(int adcPin, int sclPin, int sdaPin, int i2cBusId = 1)
        {
            _adcPin = adcPin;

            // Configurar Pines I2C
            if (i2cBusId == 1)
            {
                Configuration.SetPinFunction(sclPin, DeviceFunction.I2C1_CLOCK);
                Configuration.SetPinFunction(sdaPin, DeviceFunction.I2C1_DATA);
            }
            else
            {
                Configuration.SetPinFunction(sclPin, DeviceFunction.I2C2_CLOCK);
                Configuration.SetPinFunction(sdaPin, DeviceFunction.I2C2_DATA);
            }

            // Inicializar Pantalla OLED (0x3C de dirección de esclavo)
            I2cConnectionSettings settings = new I2cConnectionSettings(i2cBusId, 0x3C, I2cBusSpeed.FastMode);
            I2cDevice i2cDevice = I2cDevice.Create(settings);
            _oled = new Ssd1306(i2cDevice, Ssd1306.DisplayResolution.OLED128x64);
            _oled.Font = new Sinclair8x8();
            _oled.ClearScreen();


            // Inicializar ADC
            _adc = new AdcController();
            _adcChannel = _adc.OpenChannel(0);
        }

        public void UpdateDisplay()
        {
            try
            {
                
                // Leer el valor del ADC
                int rawValue = _adcChannel.ReadValue();

                // Convertir el valor crudo a voltaje en el pin (0 a 3.3V)
                double pinVoltage = (rawValue * 3.3) / 4095;

                // Reconstruir el voltaje real de la batería (9.3V/3.3V = 2.818)
                double batteryVoltage = pinVoltage * 2.818;

                // Calcular porcentaje (7.2V = 0%, 9.3V = 100%)
                double percentage = ((batteryVoltage - 7.2) / (9.3 - 7.2)) * 100;

                // Limitar porcentaje entre 0 y 100
                if (percentage > 100) percentage = 100;
                if (percentage < 0) percentage = 0;

                // Dibujar en la pantalla OLED




                string newVoltsText = $"Volts: {batteryVoltage:F2} V";
                string newBatText = $"Bat:   {percentage:F0} %";
                // Si no hay cambios en el texto, salimos inmediatamente para no sobrecargar el bus I2C
                if (newVoltsText == _lastVoltsText && newBatText == _lastBatText)
                {
                    return;
                }

                if (_lastVoltsText != "")
                {
                    _oled.DrawString(2, 20, _lastVoltsText, 1, false);
                    _oled.DrawString(2, 35, _lastBatText, 1, false);
                }

                _oled.DrawString(2, 20, newVoltsText, 1, true); 
                _oled.DrawString(2, 35, newBatText, 1, true);
                if(percentage < 20)
                {
                    _oled.DrawString(2, 50, "Battery Low!", 1, true);
                    LED_LowBatteryController.Write(5, PinValue.High);
                }
                _oled.Display();

                _lastVoltsText = newVoltsText;
                _lastBatText = newBatText;
            }
            catch (Exception ex)
            {
                Console.WriteLine("[OLED] Error actualizando pantalla: " + ex.Message);
            }
        }
        public void DisplayText(string text, int x, int y)
        {
            try
            {
                _oled.ClearScreen();

                int screenWidth = 128;
                int fontWidth = 8;
                int lineHeight = 10; 

                int maxCharsPerLine = (screenWidth - x) / fontWidth;

                int currentY = y;
                string currentLine = "";

                for (int i = 0; i < text.Length; i++)
                {
                    if (currentLine.Length == 0 && text[i] == ' ')
                    {
                        continue;
                    }

                    currentLine += text[i];

                    if (currentLine.Length == maxCharsPerLine)
                    {
                        _oled.DrawString(x, currentY, currentLine, 1, true);
                        currentLine = ""; 
                        currentY += lineHeight; 
                    }
                }

                if (currentLine.Length > 0)
                {
                    _oled.DrawString(x, currentY, currentLine, 1, true);
                }

                _oled.Display();
            }
            catch (Exception ex)
            {
                Console.WriteLine("[OLED] Error mostrando texto: " + ex.Message);
            }
        }

        public void ClearDisplay()
        {
            try
            {
                _oled.ClearScreen();

                _oled.Display();

                _lastVoltsText = "";
                _lastBatText = "";
            }
            catch (Exception ex)
            {
                Console.WriteLine("[OLED] Error limpiando pantalla: " + ex.Message);
            }
        }
    }
}