MQTT Dashboard Client Backup Archive (V2)
===============================================================

Archive Contents:
-----------------
1. database.db      - Filtered application database
2. preferences.json - Application settings and preferences
3. metadata.json    - Backup metadata and integrity information
4. README.txt       - This file
5. signature.sig    - Digital signature for verification

Backup Information:
------------------
Created:       2026-05-03 19:21:09
App Version:   1.18.7 (281)
Device:        SM-S921B (samsung)
Android:       16
Database Size: 245760 bytes
Includes Logs: false
Tables Count:  18

Integrity Verification:
----------------------
To verify backup integrity:
1. Check that all files are present
2. Verify SHA-256 checksums in metadata.json
3. Validate digital signature

Restoration Instructions:
------------------------
1. Open MQTT Dashboard Client app
2. Go to Settings → Backup & Restore
3. Select "Restore Backup"
4. Choose this archive file

Security Note:
-------------
This backup contains application data and preferences.
Store securely and do not share with unauthorized parties.

Data Retention:
---------------
Logs: Excluded
Database: Complete schema with 18 tables
Settings: All application preferences

Technical Details:
-----------------
Format Version: 2
Compression: ZIP/DEFLATE
Signature: mqtt_client_backup_v2

© 2026 MQTT Dashboard Client
Proprietary and confidential.
Unauthorized copying, modification, distribution, or use is strictly prohibited.
