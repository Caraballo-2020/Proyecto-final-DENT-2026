﻿using System;
using System.IO;
using nanoFramework.System.IO.FileSystem;

namespace tarjeta_sd_clase
{
    public class GestorTarjetaSD : IDisposable
    {
        private SDCard _tarjetaSD;
        private readonly uint _busSpi;
        private readonly uint _pinSeleccionChip;
        private readonly string _rutaRaiz;

        public bool EstaMontada => _tarjetaSD != null && _tarjetaSD.IsMounted;
        public string RutaRaiz => _rutaRaiz;

        public GestorTarjetaSD(uint busSpi, uint pinSeleccionChip, string rutaRaiz = @"D:\")
        {
            _busSpi = busSpi;
            _pinSeleccionChip = pinSeleccionChip;
            _rutaRaiz = NormalizarRuta(rutaRaiz);
        }

        public bool Montar(out string error)
        {
            error = string.Empty;

            try
            {
                if (EstaMontada)
                {
                    return true;
                }

                _tarjetaSD = new SDCard(new SDCardSpiParameters
                {
                    spiBus = _busSpi,
                    chipSelectPin = _pinSeleccionChip
                });

                _tarjetaSD.Mount();

                if (!_tarjetaSD.IsMounted)
                {
                    error = "La tarjeta SD no quedó montada.";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        public void Desmontar()
        {
            if (_tarjetaSD != null && _tarjetaSD.IsMounted)
            {
                _tarjetaSD.Unmount();
            }
        }

        public void Dispose()
        {
            Desmontar();
            _tarjetaSD = null;
        }

        public void EscribirTexto(string nombreArchivo, string contenido, bool anexar = false)
        {
            VerificarMontaje();

            string ruta = ConstruirRuta(nombreArchivo);

            using (var flujo = new FileStream(
                ruta,
                anexar ? FileMode.Append : FileMode.Create,
                FileAccess.Write,
                FileShare.Read))
            {
                using (var escritor = new StreamWriter(flujo))
                {
                    escritor.Write(contenido);
                    escritor.Flush();
                }
            }
        }
        public byte[] LeerBytes(string nombreArchivo)
        {
            VerificarMontaje();

            string ruta = ConstruirRuta(nombreArchivo);

            using (var flujo = new FileStream(
                ruta,
                FileMode.Open,
                FileAccess.Read,
                FileShare.Read))
            {
                byte[] buffer = new byte[flujo.Length];
                flujo.Read(buffer, 0, buffer.Length);
                return buffer;
            }
        }

        public string LeerTexto(string nombreArchivo)
        {
            VerificarMontaje();

            string ruta = ConstruirRuta(nombreArchivo);

            using (var flujo = new FileStream(
                ruta,
                FileMode.Open,
                FileAccess.Read,
                FileShare.Read))
            {
                using (var lector = new StreamReader(flujo))
                {
                    return lector.ReadToEnd();
                }
            }
        }

        public bool ExisteArchivo(string nombreArchivo)
        {
            VerificarMontaje();
            return File.Exists(ConstruirRuta(nombreArchivo));
        }

        public void EliminarArchivo(string nombreArchivo)
        {
            VerificarMontaje();

            string ruta = ConstruirRuta(nombreArchivo);
            if (File.Exists(ruta))
            {
                File.Delete(ruta);
            }
        }

        public string[] ListarArchivos()
        {
            VerificarMontaje();
            return Directory.GetFiles(_rutaRaiz);
        }

        public string[] ListarArchivos(string subCarpeta)
        {
            VerificarMontaje();
            return Directory.GetFiles(ConstruirRuta(subCarpeta));
        }

        private void VerificarMontaje()
        {
            if (!EstaMontada)
            {
                throw new InvalidOperationException("La tarjeta SD no está montada.");
            }
        }

        private string ConstruirRuta(string rutaRelativaONombreArchivo)
        {
            string raizLimpia = NormalizarRuta(_rutaRaiz);
            string relativaLimpia = (rutaRelativaONombreArchivo ?? string.Empty).TrimStart('\\', '/');

            if (string.IsNullOrEmpty(relativaLimpia))
            {
                return raizLimpia;
            }

            if (raizLimpia.EndsWith(@"\"))
            {
                return raizLimpia + relativaLimpia;
            }

            return raizLimpia + @"\" + relativaLimpia;
        }

        private string NormalizarRuta(string ruta)
        {
            if (string.IsNullOrEmpty(ruta))
            {
                return @"D:\";
            }

            if (!ruta.EndsWith(@"\"))
            {
                ruta += @"\";
            }

            return ruta;
        }
    }
}