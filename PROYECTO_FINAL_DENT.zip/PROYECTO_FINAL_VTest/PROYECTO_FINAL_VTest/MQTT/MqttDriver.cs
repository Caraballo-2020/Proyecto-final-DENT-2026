﻿using nanoFramework.M2Mqtt;
using nanoFramework.M2Mqtt.Messages;
using System;
using System.Diagnostics;
using System.Text;
using System.Threading;

namespace PROYECTO_FINAL_VTest.Mqtt
{
    internal class MqttDriver
    {
        private MqttClient _mqttClient;
        private MqttConfig _config;
        private string _clientId;

        // Delegado y evento para notificar al programa principal cuando llega un comando
        public delegate void CommandReceivedHandler(string topic, string jsonPayload);
        public event CommandReceivedHandler OnCommandReceived;

        public MqttDriver(MqttConfig config)
        {
            _config = config;
            _clientId = "Gateway-DENT_" + Guid.NewGuid().ToString();
        }

        public bool Initialize()
        {
            try
            {
                // Se inicializa el cliente con la dirección del Broker
                _mqttClient = new MqttClient(_config.brokerAddress);

                // Asignación de eventos
                _mqttClient.ConnectionClosed += Client_ConnectionClosed;
                _mqttClient.ConnectionClosedRequest += Client_ConnectionClosedRequest;
                _mqttClient.ConnectionOpened += Client_ConnectionOpened;
                _mqttClient.MqttMsgPublished += Client_MqttMsgPublished;
                _mqttClient.MqttMsgPublishReceived += Client_MqttMsgPublishReceived;
                _mqttClient.MqttMsgSubscribed += Client_MqttMsgSubscribed;
                _mqttClient.MqttMsgUnsubscribed += Client_MqttMsgUnsubscribed;
                _mqttClient.Authentication += Client_Authentication;

                // Conexión
                MqttReasonCode res = _mqttClient.Connect(_clientId,
                    string.IsNullOrEmpty(_config.username) ? null : _config.username,
                    string.IsNullOrEmpty(_config.password) ? null : _config.password,
                    false, MqttQoSLevel.AtMostOnce, false, null, null, true, 15);

                if (res == MqttReasonCode.Success)
                {
                    Console.WriteLine("MQTT Inicializado y Conectado al Broker.");

                    // Suscribirse al topic de recepción de comandos
                    _mqttClient.Subscribe(
                        new string[] { _config.subscribeTopic },
                        new MqttQoSLevel[] { MqttQoSLevel.AtMostOnce });

                    return true;
                }
                else
                {
                    Console.WriteLine("Fallo en la conexión MQTT. Razón: " + res.ToString());
                    return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error configurando MQTT: {ex.Message}");
                return false;
            }
        }

        public bool PublishData(string jsonPayload)
        {
            try
            {
                if (_mqttClient != null && _mqttClient.IsConnected)
                {
                    _mqttClient.Publish(_config.publishTopic, Encoding.UTF8.GetBytes(jsonPayload));
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error publicando en MQTT: {ex.Message}");
                return false;
            }
        }

        public bool IsConnected => _mqttClient != null && _mqttClient.IsConnected;

        // Eventos

        private void Client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string payload = Encoding.UTF8.GetString(e.Message, 0, e.Message.Length);
            Console.WriteLine($"Mensaje recibido en {e.Topic}: {payload}");

            // Disparar el evento hacia el programa principal
            OnCommandReceived?.Invoke(e.Topic, payload);
        }

        private void Client_ConnectionClosed(object sender, EventArgs e)
        {
            Console.WriteLine("MQTT Desconectado.");
        }

        private void Client_ConnectionClosedRequest(object sender, ConnectionClosedRequestEventArgs e)
        {
            Console.WriteLine("MQTT Connection Closed Request");
        }

        private void Client_ConnectionOpened(object sender, ConnectionOpenedEventArgs e)
        {
            Console.WriteLine("MQTT Connection Opened");
        }

        private void Client_MqttMsgPublished(object sender, MqttMsgPublishedEventArgs e)
        {
            Console.WriteLine("MQTT Msg Published Event, Msg ID: " + e.MessageId.ToString() + ", Published: " + e.IsPublished.ToString());
        }

        private void Client_MqttMsgSubscribed(object sender, MqttMsgSubscribedEventArgs e)
        {
            Console.WriteLine("MQTT Subscribed Event, Msg ID: " + e.MessageId.ToString());
        }

        private void Client_MqttMsgUnsubscribed(object sender, MqttMsgUnsubscribedEventArgs e)
        {
            Console.WriteLine("MQTT Unsubscribed Event, Msg ID: " + e.MessageId.ToString());
        }

        private void Client_Authentication(object sender, MqttMsgAuthenticationEventArgs e)
        {
            Console.WriteLine("MQTT Authentication Event");
        }
    }
}