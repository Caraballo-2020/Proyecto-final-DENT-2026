﻿using Iot.Device.Modbus.Client;
using nanoFramework.Hardware.Esp32;
using System;
using System.Diagnostics;
//using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;

namespace PROYECTO_FINAL_VTest.Modbus
{
    // Driver para el protocolo Modbus. Este driver se encargará de manejar la comunicación con dispositivos que utilizan este protocolo, como sensores, actuadores, etc. El driver implementará las funciones necesarias para enviar y recibir datos a través de Modbus, así como para interpretar los mensajes recibidos y generar los mensajes de respuesta adecuados.
    internal class ModbusDriver
    {
        #region Inicialización y Atributos
        // Atributos      
        private ModbusClient _modbusClient;
        private SerialPort _serialPort;
        public int _baudRate;
        public int _dataBits = 8;
        Parity _parity;
        StopBits _stopBits;
        public int _TX; // Pin GPIO17 para transmisión (TX)
        public int _RX;

        //private readonly byte _defaultSlaveId = 1;
        #endregion
        #region Constructor

        public ModbusDriver(ModbusConfig config, int tx, int rx)
        {
            _baudRate = config.baudRate;
            _dataBits = config.dataBits;
            if(config.parity == "none")
                _parity = Parity.None;
            else if(config.parity == "even")
                _parity = Parity.Even;
            else _parity = Parity.Odd;
            
                
            if(config.stopBits == 1)
                _stopBits = StopBits.One;
            else _stopBits = StopBits.Two;
           
            _TX = tx;
            _RX = rx;
        }
        #endregion
        #region Inicialización del Driver
        public bool Initialize()
        {
            try
            {
                if (_serialPort != null && _serialPort.IsOpen)
                {
                    Debug.WriteLine("Puerto ya abierto, reutilizando.");
                    return true;
                }
                // Modbus requiere usar la UART para cada envío del protocolo, por lo que se deben configurar los pines de la UART para su uso. En este caso, se configurarán los pines asignados para la transmisión (TX) y recepción (RX) respectivamente al COM1.
                Configuration.SetPinFunction(_TX, DeviceFunction.COM2_TX);
                Configuration.SetPinFunction(_RX, DeviceFunction.COM2_RX);
                /* Parametros del puerto serial:
                 - Puerto COM2 para la comunicación serial de la UART
                 - Velocidad de 9600 Baudios
                 - No se usará bit de paridad de la UART
                 - Trama de 8 bits por envío de la UART
                 - Un solo bit de Stop para cada transmisión*/
                _serialPort = new SerialPort("COM2", _baudRate, _parity, _dataBits, _stopBits);
                _serialPort.ReadTimeout = 2000;
                _serialPort.WriteTimeout = 1000;
                _serialPort.Open(); // Abrir el puerto serial para la comunicación

                // Se crea una instancia del cliente Modbus utilizando el puerto serial configurado. El cliente Modbus se encargará de manejar la comunicación con los dispositivos Modbus conectados a través del puerto serial, permitiendo enviar y recibir mensajes Modbus de manera sencilla.
                _modbusClient = new ModbusClient(_serialPort, SerialMode.Normal); // Usa SerialMode.Normal para el RS232
                Debug.WriteLine("Modbus inicializado correctamente en COM1");
                return true;
            }
            catch (Exception ex)
            {
                // En caso de error durante la configuración del puerto serial, se captura la excepción y se muestra un mensaje de error en la consola. Esto es importante para identificar problemas de configuración o conexión con el puerto serial, lo que podría afectar la comunicación Modbus.
                Debug.WriteLine($"Error configurando el puerto Serial: {ex.Message}");
                return false;
            }
        }
        #endregion

        #region Funciones de Comunicación Modbus
        /* Se utiliza la libreria IoT.Device.Modbus.Client para implementar las funciones de comunicación Modbus.
          Estas funciones permiten enviar y recibir mensajes Modbus a través del puerto serial configurado, facilitando la interacción con dispositivos Modbus conectados.
        */

        public short[] ReadRegisters(byte SlaveId, ushort startAddress, ushort RegistersQuantity)
        {
                try
                {
                    // Se utiliza el método ReadHoldingRegisters del cliente Modbus para leer los registros de un dispositivo Modbus específico. Este método requiere el ID del esclavo (SlaveId), la dirección de inicio (startAddress) y la cantidad de registros a leer (RegistersQuantity). El método devuelve un array de valores cortos (short[]) que representan los datos leídos de los registros solicitados.
                    // Lee solamente los registros consecutivos al registro de inicio especificado
                    short[] ReadValues = _modbusClient.ReadHoldingRegisters(SlaveId, startAddress, RegistersQuantity);
                    if (ReadValues == null)
                    {
                        Debug.WriteLine("Lectura fallida: sin respuesta del esclavo");
                        return null;
                    }
                    Debug.WriteLine($"Lectura exitosa: {ReadValues.Length} registros");

                    // Se imprimen los valores recibidos para verificar:
                    for (int i = 0; i < ReadValues.Length; i++)
                    {
                        Debug.WriteLine($"Registro {startAddress + i}: {ReadValues[i]}");
                    }
                    // Se retorna un vector de valores leidos de los registros solicitados
                    return ReadValues;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"ERROR tipo: {ex.GetType().Name}");
                    Debug.WriteLine($"ERROR mensaje: {ex.Message}");
                    Debug.WriteLine($"ERROR stack: {ex.StackTrace}");
                    return null;
                }

        }

        public bool WriteOnlyRegister(byte SlaveId, ushort RegisterAddress, short WriteValue)
        {
                try
                {
                    // Se utiliza el método WriteSingleRegister del cliente Modbus para escribir un valor en un registro específico de un dispositivo Modbus. Este método requiere el ID del esclavo (SlaveId), la dirección del registro (RegisterAddress) y el valor a escribir (WriteValue). El método no devuelve ningún valor, pero se encarga de enviar el mensaje Modbus correspondiente para realizar la escritura en el dispositivo.
                    _modbusClient.WriteSingleRegister(SlaveId, RegisterAddress, WriteValue);
                    return true; // Retorna true si la escritura se realizó correctamente
                }
                catch (Exception ex)
                {
                    // En caso de error durante la escritura del registro Modbus, se captura la excepción y se muestra un mensaje de error en la consola. Esto es importante para identificar problemas de comunicación o errores en los parámetros proporcionados para la escritura, lo que podría afectar la correcta actualización del registro en el dispositivo Modbus.
                    Debug.WriteLine($"Error escribiendo registro Modbus: {ex.Message}");
                    return false; // Retorna false si hubo un error durante la escritura
                }
        }
        public bool WriteMultipleRegisters(byte SlaveId, ushort startAddress, ushort[] WriteValues)
        {
            try
            {
                // Se utiliza el método WriteMultipleRegisters del cliente Modbus para escribir múltiples valores en registros consecutivos de un dispositivo Modbus. Este método requiere el ID del esclavo (SlaveId), la dirección de inicio (startAddress) y un array de valores a escribir (WriteValues). El método se encarga de enviar el mensaje Modbus correspondiente para realizar la escritura en los registros especificados.
                _modbusClient.WriteMultipleRegisters(SlaveId, startAddress, WriteValues);
                return true;
            }
            catch (Exception ex)
            {
                // En caso de error durante la escritura de múltiples registros Modbus, se captura la excepción y se muestra un mensaje de error en la consola. Esto es importante para identificar problemas de comunicación o errores en los parámetros proporcionados para la escritura, lo que podría afectar la correcta actualización de los registros en el dispositivo Modbus.
                Debug.WriteLine($"Error escribiendo múltiples registros Modbus: {ex.Message}");
                return false;

            }
        }
        #endregion

    }

}