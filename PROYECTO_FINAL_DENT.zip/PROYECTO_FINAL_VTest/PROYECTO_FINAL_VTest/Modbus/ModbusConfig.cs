﻿using nanoFramework.Json;
using PROYECTO_FINAL_VTest.Modbus.Models;
using System;
using System.Collections;
using System.IO;
using System.Text;

namespace PROYECTO_FINAL_VTest.Modbus
{

    // Configuración del puerto serie RS232 y la lista de registros Modbus.
    // Se carga/guarda en D:\ModbusCfg.txt como JSON en la microSD. Si el archivo no existe, se crea con una configuración por defecto con 16 registros de ejemplo iguales a los de la página


    internal class ModbusConfig
    {
        // Configuración del puerto serie 
        public int baudRate { get; set; } = 9600;
        public int dataBits { get; set; } = 8;
        public string parity { get; set; } = "none";
        public int stopBits { get; set; } = 1;
        public int responseTimeout { get; set; } = 2000;
        public int defaultSlaveId { get; set; } = 1;
        public int interFrameDelay { get; set; } = 20;
        public int retries { get; set; } = 3;
        // Sin inicializar aquí para evitar que nanoFramework.Json intente deserializar el array automáticamente al cargar desde SD
        public ModbusRegister[] registers { get; set; } = DefaultRegisters();

        // ── Persistencia (mismo patrón que WifiConfig) ────────────────────
        public static ModbusConfig FromJson(string json)
        {
            if (string.IsNullOrEmpty(json)) return new ModbusConfig();

            try
            {
                string registersJson = null;
                string jsonSinRegisters = json;

                // 1. Extraer y quitar el bloque "registers":[...]
                int regStart = json.IndexOf("\"registers\"");
                if (regStart >= 0)
                {
                    int arrStart = json.IndexOf('[', regStart);
                    int depth = 0, arrEnd = -1;
                    for (int i = arrStart; i < json.Length; i++)
                    {
                        if (json[i] == '[') depth++;
                        else if (json[i] == ']') { depth--; if (depth == 0) { arrEnd = i; break; } }
                    }

                    if (arrStart >= 0 && arrEnd >= 0)
                    {
                        registersJson = json.Substring(arrStart, arrEnd - arrStart + 1);
                        int comaBefore = json.LastIndexOf(',', regStart);
                        if (comaBefore >= 0)
                            jsonSinRegisters = json.Substring(0, comaBefore) + json.Substring(arrEnd + 1);
                        else
                            jsonSinRegisters = json.Substring(0, regStart) + json.Substring(arrEnd + 1);
                        int cierreObj = jsonSinRegisters.LastIndexOf('}');
                        int ultimaComa = jsonSinRegisters.LastIndexOf(',', cierreObj);
                        if (ultimaComa >= 0)
                        {
                            // Verificar que entre la coma y el cierre solo haya espacios
                            bool soloEspacios = true;
                            for (int k = ultimaComa + 1; k < cierreObj; k++)
                            {
                                if (jsonSinRegisters[k] != ' ' && jsonSinRegisters[k] != '\r' && jsonSinRegisters[k] != '\n')
                                {
                                    soloEspacios = false;
                                    break;
                                }
                            }
                            if (soloEspacios)
                                jsonSinRegisters = jsonSinRegisters.Substring(0, ultimaComa) +
                                                   jsonSinRegisters.Substring(cierreObj);
                        }
                    }
                }

                // 2. Deserializar campos simples
                ModbusConfig cfg = (ModbusConfig)JsonConvert.DeserializeObject(
                    jsonSinRegisters, typeof(ModbusConfig));

                if (cfg == null) cfg = new ModbusConfig();

                // 3. Deserializar registros uno por uno
                if (registersJson != null)
                {
                    string inner = registersJson.Trim();
                    if (inner.StartsWith("[")) inner = inner.Substring(1);
                    if (inner.EndsWith("]")) inner = inner.Substring(0, inner.Length - 1);

                    ArrayList regList = new ArrayList();
                    int pos = 0;
                    while (pos < inner.Length)
                    {
                        int objStart = inner.IndexOf('{', pos);
                        if (objStart < 0) break;

                        int d = 0, objEnd = -1;
                        for (int i = objStart; i < inner.Length; i++)
                        {
                            if (inner[i] == '{') d++;
                            else if (inner[i] == '}') { d--; if (d == 0) { objEnd = i; break; } }
                        }
                        if (objEnd < 0) break;

                        string objJson = inner.Substring(objStart, objEnd - objStart + 1);
                        ModbusRegister reg = (ModbusRegister)JsonConvert.DeserializeObject(
                            objJson, typeof(ModbusRegister));
                        if (reg != null) regList.Add(reg);

                        pos = objEnd + 1;
                    }

                    cfg.registers = new ModbusRegister[regList.Count];
                    for (int i = 0; i < regList.Count; i++)
                        cfg.registers[i] = (ModbusRegister)regList[i];

                    Console.WriteLine("Registros deserializados: " + cfg.registers.Length);
                }

                return cfg;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error en ModbusConfig.FromJson: " + ex.Message);
                return new ModbusConfig();
            }
        }

         
        public static ModbusConfig LoadConfig(string path)
        {
            try
            {
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                {
                    using (FileStream f = new FileStream(path, FileMode.Open, FileAccess.Read))
                    {
                        byte[] buff = new byte[f.Length];
                        f.Read(buff, 0, (int)f.Length);
                        string json = Encoding.UTF8.GetString(buff, 0, buff.Length);
                        if (!string.IsNullOrEmpty(json))
                        {
                            Console.WriteLine("Configuración Modbus cargada desde SD.");
                            // Usar FromJson en lugar de DeserializeObject directo
                            return FromJson(json);
                        }
                    }
                }
                else
                {
                    ModbusConfig def = new ModbusConfig();
                    if (SaveConfig(def, path))
                        Console.WriteLine("Configuración Modbus por defecto guardada en SD.");
                    return def;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al cargar configuración Modbus: " + ex.Message);
            }
            return new ModbusConfig();
        }

        public static bool SaveConfig(ModbusConfig config, string path)
        {
            bool res = false;
            try
            {
                if (config != null && !string.IsNullOrEmpty(path))
                {
                    using (FileStream f = new FileStream(path, FileMode.Create, FileAccess.Write))
                    {
                        string json = JsonConvert.SerializeObject(config);
                        if (!string.IsNullOrEmpty(json))
                        {
                            byte[] buff = Encoding.UTF8.GetBytes(json);
                            f.Write(buff, 0, buff.Length);
                            Console.WriteLine("Configuración Modbus guardada en SD.");
                            res = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al guardar configuración Modbus: " + ex.Message);
            }
            return res;
        }

        // 16 registros por defecto
        private static ModbusRegister[] DefaultRegisters()
        {
            return new ModbusRegister[]
            {
            // Dirección 0 a 9 (Columna izquierda de modbusSlave)
            new ModbusRegister { name="Temperatura ambiente", slave=1, function="03", address=0, dataType="INT16", scale=0.1, unit="°C" },
            new ModbusRegister { name="Temperatura motores",  slave=1, function="03", address=1, dataType="INT16", scale=0.1, unit="°C" },
            new ModbusRegister { name="Temperatura batería",  slave=1, function="03", address=2, dataType="INT16", scale=0.1, unit="°C" },
            new ModbusRegister { name="Presión atmosférica",  slave=1, function="03", address=3, dataType="INT16", scale=1.0, unit="hPa" },
            new ModbusRegister { name="Humedad",              slave=1, function="03", address=4, dataType="INT16", scale=1.0, unit="%" },
            new ModbusRegister { name="Carga batería",        slave=1, function="03", address=5, dataType="INT16", scale=1.0, unit="%" },
            new ModbusRegister { name="Velocidad rover",      slave=1, function="03", address=6, dataType="INT16", scale=1.0, unit="cm/s" },
            new ModbusRegister { name="Corriente consumo",    slave=1, function="03", address=7, dataType="INT16", scale=1.0, unit="mA" },
            new ModbusRegister { name="Potencia consumo",     slave=1, function="03", address=8, dataType="INT16", scale=1.0, unit="W" },
            new ModbusRegister { name="Calidad del aire",     slave=1, function="03", address=9, dataType="INT16", scale=1.0, unit="AQI" },

            // Dirección 10 a 15 (Columna derecha de modbusSlave)
            new ModbusRegister { name="Radiación solar",      slave=1, function="03", address=10, dataType="INT16", scale=1.0, unit="W/m2" },
            new ModbusRegister { name="RPM motores",          slave=1, function="03", address=11, dataType="INT16", scale=1.0, unit="RPM" },
            new ModbusRegister { name="Estado motores",       slave=1, function="03", address=12, dataType="INT16", scale=1.0, unit="" },
            new ModbusRegister { name="Velocidad viento",     slave=1, function="03", address=13, dataType="INT16", scale=1.0, unit="m/s" },
            new ModbusRegister { name="Radiación UV",         slave=1, function="03", address=14, dataType="INT16", scale=1.0, unit="UV" },
            new ModbusRegister { name="Aceleración lineal",   slave=1, function="03", address=15, dataType="INT16", scale=0.1, unit="m/s2" } 
            };
        }
    }
}