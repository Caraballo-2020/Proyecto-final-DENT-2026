﻿using System.Collections;

namespace PROYECTO_FINAL_VTest.Modbus.Models
{
    // Representa un registro Modbus individual para lectura periódica.
    // Se serializa/deserializa desde ModbusCfg.txt en la SD.
    public class ModbusRegister
    {
        //Etiqueta legible, se usa como clave en el JSON publicado por MQTT. Ej: "Voltaje L1"
        public string name { get; set; } = "Registro";

        /// <summary>ID del esclavo Modbus (1-247)</summary>
        public byte slave { get; set; } = 1;

        //Código de función: "03" = Holding Registers
        public string function { get; set; } = "03";

        /// <summary>Dirección del primer registro a leer (0-65535)</summary>
        public ushort address { get; set; } = 0;

        /// <summary>Tipo de dato: INT16, UINT16, INT32, UINT32, FLOAT32, BOOL, COIL</summary>
        public string dataType { get; set; } = "UINT16";

        /// <summary>Factor de escala que se multiplica al valor crudo antes de publicar</summary>
        public double scale { get; set; } = 1.0;

        /// <summary>Unidad de medida para el JSON. Ej: "V", "A", "kWh"</summary>
        public string unit { get; set; } = "";

    }

    public class RegValue
    {
        public string Name { get; set; } = "";
        public string Value { get; set; } = "";

    }

    public class Report
    {
        public string DeviceID { get; set; } = "";
        public string TimeStamp { get; set; } = "";
        public ArrayList Registers { get; set; } = new ArrayList();

    }
}