﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PROYECTO_FINAL_VTest.Modbus.Models
{
    public class ModbusCommand
    {
        public byte SlaveId { get; set; }
        public ushort Address { get; set; }
        public Int64 Value { get; set; }
    }
}
