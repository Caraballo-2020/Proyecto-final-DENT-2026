﻿using nanoFramework.Json;
using System;
using System.Device.Wifi;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using tarjeta_sd_clase;
using PROYECTO_FINAL_VTest.Mqtt;
using PROYECTO_FINAL_VTest.Modbus;

namespace PROYECTO_FINAL_VTest.Utils
{
    internal class HttpFunctions
    {
        // Atributos
        public int Port { get; private set; }
        private GestorTarjetaSD _sd;

        // Constructor
        public HttpFunctions(int port, GestorTarjetaSD sd)
        {
            Port = port;
            _sd = sd;
        }

        public static void HandleHttpRequest(HttpListenerContext Context, GestorTarjetaSD sd, WifiConfig wifiConfig, string WIFI_CONFIG_FILE_NAME, MqttConfig mqttConfig, string MQTT_CONFIG_FILE_NAME, ModbusConfig modbusConfig, string MODBUS_CONFIG_FILE_NAME)
        {
            if (Context == null)
            {
                Console.WriteLine("http context is null");
                return;
            }
            if (Context.Request != null)
            {
                try
                {
                    Console.WriteLine("http request received: " + Context.Request.HttpMethod + ", URL " + Context.Request.RawUrl);

                    // Permitir solicitudes desde cualquier origen (CORS) para evitar bloqueos del navegador
                    Context.Response.Headers.Add("Access-Control-Allow-Origin", "*");

                    switch (Context.Request.RawUrl)
                    {
                        case "/":
                        case "":
                        case "/index.html":
                            {
                                // Leer desde la MicroSD la página HTML y enviarla como respuesta
                                if (sd != null && sd.EstaMontada && sd.ExisteArchivo("pagina.html"))
                                {
                                    byte[] Buff = sd.LeerBytes("pagina.html");
                                    Context.Response.StatusCode = (int)HttpStatusCode.OK;
                                    Context.Response.ContentType = "text/html; charset=UTF-8";
                                    Context.Response.ContentLength64 = Buff.Length;
                                    Context.Response.OutputStream.Write(Buff, 0, Buff.Length);
                                }
                                else
                                {
                                    // Si alguien sacó la tarjeta o borró el archivo
                                    Context.Response.StatusCode = (int)HttpStatusCode.NotFound;
                                    byte[] errorMsg = Encoding.UTF8.GetBytes("<h1>Error 404</h1><p>Archivo pagina.html no encontrado en la MicroSD.</p>");
                                    Context.Response.ContentLength64 = errorMsg.Length;
                                    Context.Response.OutputStream.Write(errorMsg, 0, errorMsg.Length);
                                }
                            }
                            break;

                        case "/favicon.ico":
                            {
                                // Leer la imagen desde la MicroSD
                                
                                if (sd != null && sd.EstaMontada && sd.ExisteArchivo("favicon.png"))
                                {
                                    byte[] Buff = sd.LeerBytes("favicon.png");
                                    Context.Response.StatusCode = (int)HttpStatusCode.OK;
                                    Context.Response.ContentType = "image/png";
                                    Context.Response.ContentLength64 = Buff.Length;
                                    Context.Response.OutputStream.Write(Buff, 0, Buff.Length);
                                }
                                else
                                {
                                    Context.Response.StatusCode = (int)HttpStatusCode.NotFound;
                                    Context.Response.ContentLength64 = 0;
                                }
                            }
                            break;

                        case "/api/config/wifi":
                            {
                                if (Context.Request.HttpMethod == "POST" && Context.Request.ContentLength64 > 0)
                                {
                                    try
                                    {
                                        byte[] RxBuff = new byte[Context.Request.ContentLength64];
                                        Context.Request.InputStream.Read(RxBuff, 0, RxBuff.Length);
                                        string Data = Encoding.UTF8.GetString(RxBuff, 0, RxBuff.Length);
                                        Console.WriteLine("Received WiFi config: " + Data);

                                        // Procesar el JSON recibido para extraer el SSID y la contraseña
                                        WifiConfig Cfg = (WifiConfig)JsonConvert.DeserializeObject(Data, typeof(WifiConfig));

                                        wifiConfig = Cfg;
                                        Console.WriteLine("Intentando Guardar configuración de la red: " + wifiConfig.ssid.ToString());
                                        WifiConfig.SaveConfig(wifiConfig, WIFI_CONFIG_FILE_NAME);

                                        Context.Response.StatusCode = (int)HttpStatusCode.OK;
                                        Context.Response.ContentLength64 = 0;

                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine("Error processing WiFi config: " + ex.Message.ToString());
                                        Context.Response.StatusCode = (int)HttpStatusCode.ExpectationFailed;
                                        Context.Response.ContentLength64 = 0;
                                    }
                                }
                                else if (Context.Request.HttpMethod == "GET")
                                {
                                    // GET, se devuelve el estado actual de la conexión WiFi en formato JSON
                                    string json = JsonConvert.SerializeObject(wifiConfig);
                                    Console.WriteLine($"[GET] Enviando WiFi -> {json}"); 

                                    byte[] Buff = Encoding.UTF8.GetBytes(json);
                                    Context.Response.StatusCode = (int)HttpStatusCode.OK;
                                    Context.Response.ContentType = "application/json; charset=UTF-8"; 
                                    Context.Response.ContentLength64 = Buff.Length;
                                    Context.Response.OutputStream.Write(Buff, 0, Buff.Length);
                                }
                                else
                                {
                                    Context.Response.StatusCode = (int)HttpStatusCode.MethodNotAllowed;
                                    Context.Response.ContentLength64 = 0;
                                }
                            }
                            break;

                        case "/api/config/mqtt":
                            {
                                if (Context.Request.HttpMethod == "POST" && Context.Request.ContentLength64 > 0)
                                {
                                    try
                                    {
                                        byte[] RxBuff = new byte[Context.Request.ContentLength64];
                                        Context.Request.InputStream.Read(RxBuff, 0, RxBuff.Length);
                                        string Data = Encoding.UTF8.GetString(RxBuff, 0, RxBuff.Length);
                                        Console.WriteLine("Received MQTT config: " + Data);

                                        MqttConfig Cfg = (MqttConfig)JsonConvert.DeserializeObject(Data, typeof(MqttConfig));
                                        mqttConfig = Cfg;
                                        Console.WriteLine("Intentando Guardar configuración MQTT: " + mqttConfig.brokerAddress.ToString());
                                        MqttConfig.SaveConfig(mqttConfig, MQTT_CONFIG_FILE_NAME);

                                        Context.Response.StatusCode = (int)HttpStatusCode.OK;
                                        Context.Response.ContentLength64 = 0;
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine("Error processing MQTT config: " + ex.Message.ToString());
                                        Context.Response.StatusCode = (int)HttpStatusCode.ExpectationFailed;
                                        Context.Response.ContentLength64 = 0;
                                    }
                                }
                                else if (Context.Request.HttpMethod == "GET")
                                {
                                    // GET, se devuelve el estado actual de la configuración MQTT en formato JSON
                                    string json = JsonConvert.SerializeObject(mqttConfig);
                                    Console.WriteLine($"[GET] Enviando MQTT -> {json}"); 

                                    byte[] Buff = Encoding.UTF8.GetBytes(json);
                                    Context.Response.StatusCode = (int)HttpStatusCode.OK;
                                    Context.Response.ContentType = "application/json; charset=UTF-8"; 
                                    Context.Response.ContentLength64 = Buff.Length;
                                    Context.Response.OutputStream.Write(Buff, 0, Buff.Length);
                                }
                                else
                                {
                                    Context.Response.StatusCode = (int)HttpStatusCode.MethodNotAllowed;
                                    Context.Response.ContentLength64 = 0;
                                }
                            }
                            break;

                        case "/api/config/modbus":
                            {
                                if (Context.Request.HttpMethod == "POST" && Context.Request.ContentLength64 > 0)
                                {
                                    try
                                    {
                                        byte[] RxBuff = new byte[Context.Request.ContentLength64];
                                        Context.Request.InputStream.Read(RxBuff, 0, RxBuff.Length);
                                        string Data = Encoding.UTF8.GetString(RxBuff, 0, RxBuff.Length);
                                        Console.WriteLine("Received Modbus config: " + Data);

                                        ModbusConfig Cfg = ModbusConfig.FromJson(Data);

                                        modbusConfig = Cfg;
                                        Console.WriteLine("Guardando config Modbus: BaudRate=" + modbusConfig.baudRate);
                                        ModbusConfig.SaveConfig(modbusConfig, MODBUS_CONFIG_FILE_NAME);

                                        Context.Response.StatusCode = (int)HttpStatusCode.OK;
                                        Context.Response.ContentLength64 = 0;
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine("Error processing Modbus config: " + ex.Message);
                                        Context.Response.StatusCode = (int)HttpStatusCode.ExpectationFailed;
                                        Context.Response.ContentLength64 = 0;
                                    }
                                }
                                else if (Context.Request.HttpMethod == "GET")
                                {
                                    // GET, se devuelve el estado actual de la configuración Modbus en formato JSON
                                    string json = JsonConvert.SerializeObject(modbusConfig);
                                    Console.WriteLine($"[GET] Enviando Modbus -> {json}");

                                    byte[] Buff = Encoding.UTF8.GetBytes(json);
                                    Context.Response.StatusCode = (int)HttpStatusCode.OK;
                                    Context.Response.ContentType = "application/json; charset=UTF-8";
                                    Context.Response.ContentLength64 = Buff.Length;
                                    Context.Response.OutputStream.Write(Buff, 0, Buff.Length);
                                }
                                else
                                {
                                    Context.Response.StatusCode = (int)HttpStatusCode.MethodNotAllowed;
                                    Context.Response.ContentLength64 = 0;
                                }
                            }
                            break;

                        default:
                            Context.Response.StatusCode = (int)HttpStatusCode.NotFound;
                            Context.Response.ContentLength64 = 0; 
                            break;
                    }
                    Context.Response.Close();
                    Context.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error handling HTTP request: " + ex.Message.ToString());
                }
            }
        }
    }
}