﻿using System;
using System.Device.Wifi;
using System.Text;

namespace PROYECTO_FINAL_VTest.Utils
{
    internal class WifiConnectionToNetwork
    {
        public static string ConfigFilePath = "D:\\WifiCfg.txt";
        public static bool Connected = false;  // ← Program lee esto

        public WifiConnectionToNetwork(string path)
        {
            ConfigFilePath = path;
        }

        public static void WifiSta_AvailableNetworksChanged(WifiAdapter sender, object o)
        {
            WifiConfig config = WifiConfig.LoadConfig(ConfigFilePath);

            try
            {
                string ssid = config.ssid;
                Console.WriteLine("Intentando conectar a :" + ssid);
                string password = config.password;
                Console.WriteLine("Redes WiFi disponibles:");
                WifiNetworkReport report = sender.NetworkReport;
                foreach (WifiAvailableNetwork network in report.AvailableNetworks)
                {
                    Console.WriteLine("Red:" + network.Ssid + ", Rssi: " + network.NetworkRssiInDecibelMilliwatts);
                    if (network.Ssid == ssid)
                    {
                        Console.WriteLine("Red Wifi encontrada");
                        sender.Disconnect();
                        WifiConnectionResult result = sender.Connect(ssid, WifiReconnectionKind.Automatic, password);
                        if (result.ConnectionStatus == WifiConnectionStatus.Success)
                        {
                            Console.WriteLine("Conexión WiFi exitosa a " + ssid);
                            Connected = true;
                        }
                        else
                        {
                            Console.WriteLine("Error al conectar a la red WiFi: " + ssid + ", Estado: " + result.ConnectionStatus);
                            Connected = false;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

        }
    }
}
