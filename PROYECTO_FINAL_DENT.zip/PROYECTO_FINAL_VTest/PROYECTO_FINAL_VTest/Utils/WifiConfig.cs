﻿using nanoFramework.Json;
using System;
using System.Device.Wifi;
using System.IO;
using System.Text;

namespace PROYECTO_FINAL_VTest.Utils
{
    internal class WifiConfig
    {
        public string ssid { get; set; } = "eee";
        public string password { get; set; } = "macacocaco_05";
        public bool connected { get; set; } = false;
        public bool dhcp { get; set; } = true;
        public string IP { get; set; } = null;
        public string mask { get; set; } = null;
        public string gateway { get; set; } = null;
        public string dhs { get; set; } = null;



        public static WifiConfig LoadConfig(string path)
        {
            WifiConfig config = new WifiConfig();
            try
            {
                if (!string.IsNullOrEmpty(path))
                {
                    if (File.Exists(path))
                    {
                        // Usamos 'using' para asegurar que el archivo siempre se cierre, incluso si hay error
                        using (FileStream f = new FileStream(path, FileMode.Open, FileAccess.Read))
                        {
                            byte[] Buff = new byte[f.Length];
                            f.Read(Buff, 0, (int)f.Length);
                            string json = Encoding.UTF8.GetString(Buff, 0, Buff.Length);
                            if (!string.IsNullOrEmpty(json))
                            {
                                config = (WifiConfig)JsonConvert.DeserializeObject(json, typeof(WifiConfig));
                                Console.WriteLine("Configuración WiFi cargada: " + json);
                            }
                        }
                    }
                    else
                    {
                        if (SaveConfig(config, path))
                        {
                            Console.WriteLine("Configuración WiFi por defecto guardada en la SD.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al cargar la configuración WiFi: " + ex.Message);
                config = new WifiConfig();
            }
            return config;
        }

        public static bool SaveConfig(WifiConfig config, string path)
        {
            bool res = false;
            try
            {
                if (config != null && !string.IsNullOrEmpty(path))
                {
                    // Usamos FileMode.Create para sobrescribir siempre con los nuevos datos
                    using (FileStream f = new FileStream(path, FileMode.Create, FileAccess.Write))
                    {
                        string json = JsonConvert.SerializeObject(config);
                        if (!string.IsNullOrEmpty(json))
                        {
                            byte[] Buff = Encoding.UTF8.GetBytes(json);
                            f.Write(Buff, 0, Buff.Length);
                            Console.WriteLine("Configuración WiFi actualizada y guardada en SD: " + json);
                            res = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al guardar la configuración WiFi: " + ex.Message);
            }
            return res;
        }

    }
}