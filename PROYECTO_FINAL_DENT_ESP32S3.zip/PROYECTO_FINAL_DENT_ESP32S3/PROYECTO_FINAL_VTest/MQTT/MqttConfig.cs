﻿using nanoFramework.Json;
using System;
using System.IO;
using System.Text;

namespace PROYECTO_FINAL_VTest.Mqtt
{
	internal class MqttConfig
	{
		// Configuración del Broker
		public string brokerAddress { get; set; } = "broker.emqx.io";
		public int brokerPort { get; set; } = 8084;
		public string username { get; set; } = "proyecto";
		public string password { get; set; } = "dent";

		public string clientId { get; set; } = "Gateway-DENT_01";
	

        // Topics de Transmisión y Recepción
        public string publishTopic { get; set; } = "dent/gateway/01/data";  
        public string subscribeTopic { get; set; } = "dent/gateway/01/cmd";   

        // Tiempos de reporte en milisegundos
        public int reportInterval { get; set; } = 5000;

		
		public static MqttConfig LoadConfig(string path)
		{
			MqttConfig config = new MqttConfig();
			try
			{
				if (!string.IsNullOrEmpty(path))
				{
					if (File.Exists(path))
					{
						using (FileStream f = new FileStream(path, FileMode.Open, FileAccess.Read))
						{
							byte[] buff = new byte[f.Length];
							f.Read(buff, 0, (int)f.Length);
							string json = Encoding.UTF8.GetString(buff, 0, buff.Length);
							if (!string.IsNullOrEmpty(json))
							{
								config = (MqttConfig)JsonConvert.DeserializeObject(json, typeof(MqttConfig));
								
                                Console.WriteLine("Configuración MQTT cargada: " + json);
							}
						}
					}
					else
					{
						if (SaveConfig(config, path))
							Console.WriteLine("Configuración MQTT por defecto guardada en SD.");
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error al cargar configuración MQTT: " + ex.Message);
				config = new MqttConfig();
			}
			return config;
		}

		public static bool SaveConfig(MqttConfig config, string path)
		{
			bool res = false;
			try
			{
				if (config != null && !string.IsNullOrEmpty(path))
				{
					
                    using (FileStream f = new FileStream(path, FileMode.Create, FileAccess.Write))
					{
						string json = JsonConvert.SerializeObject(config);
						if (!string.IsNullOrEmpty(json))
						{
							byte[] buff = Encoding.UTF8.GetBytes(json);
							f.Write(buff, 0, buff.Length);
							
							Console.WriteLine("Configuración MQTT guardada en SD: " + json);
							res = true;
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error al guardar configuración MQTT: " + ex.Message);
			}
			return res;
		}
	}
}