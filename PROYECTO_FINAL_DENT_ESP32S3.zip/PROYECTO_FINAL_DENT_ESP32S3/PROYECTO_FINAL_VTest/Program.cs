using Iot.Device.Modbus;
using nanoFramework.Hardware.Esp32;
using nanoFramework.Json;
using nanoFramework.M2Mqtt;
using nanoFramework.M2Mqtt.Messages;
using PROYECTO_FINAL_VTest.Modbus;
using PROYECTO_FINAL_VTest.Mqtt;
using PROYECTO_FINAL_VTest.Utils;
using System;
using System.Collections;
using System.Device.Gpio;
using System.Device.Wifi;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO.Ports;
using System.Net;
using System.Net.NetworkInformation;
using System.Threading;
using PROYECTO_FINAL_VTest.Modbus.Models;
using PROYECTO_FINAL_VTest.Hardware;

namespace PROYECTO_FINAL_VTest
{
    public class Program
    {
        //Variables SPI (para tarjeta SD)
        static int MOSI = 14;
        static int MISO = 13;
        static int SCK = 12;
        static uint CS = 15;

        // Variables UART para Modbus
        static int TX = 10; // Pin GPIO10 para transmisión (TX)
        static int RX = 11; // Pin GPIO11 para recepción (RX)

        // Variables ADC (para porcentaje de batería)
        static int ADC_PIN = 1;

        // Variables I2C (Pantalla OLED)
        static int I2C_SCL = 9;
        static int I2C_SDA = 8;

        // Variables GPIO para LEDs de confirmación
        static int LED_MQTT_PIN = 6;
        static int LED_MODBUS_PIN = 16;
        static GpioController gpioController;

        // Archivos JSON de configuración
        // WiFi
        static string WIFI_CONFIG_FILE_NAME = "D:\\WifiCfg.txt";
        static WifiConfig WifiCfg = null;
        // MQTT
        static string MQTT_CONFIG_FILE_NAME = "D:\\MqttCfg.txt";
        static MqttConfig MqttCfg = null;
        static MqttDriver MqttManager = null;

        // Modbus
        static string MODBUS_CONFIG_FILE_NAME = "D:\\ModbusCfg.txt";
        static ModbusConfig ModbusCfg = null;
        static ModbusDriver ModbusManager = null;

        public static void Main()
        {
            // Inicialización de pines GPIO para los LEDs 
            gpioController = new GpioController();
            gpioController.OpenPin(LED_MQTT_PIN, PinMode.Output);
            gpioController.OpenPin(LED_MODBUS_PIN, PinMode.Output);
            gpioController.Write(LED_MQTT_PIN, PinValue.Low);
            gpioController.Write(LED_MODBUS_PIN, PinValue.Low);

            // Mapeo de GPIOs para SPI
            Configuration.SetPinFunction(MOSI, DeviceFunction.SPI1_MOSI);
            Configuration.SetPinFunction(MISO, DeviceFunction.SPI1_MISO);
            Configuration.SetPinFunction(SCK, DeviceFunction.SPI1_CLOCK);
            tarjeta_sd_clase.GestorTarjetaSD GestorSD = new tarjeta_sd_clase.GestorTarjetaSD(1, CS);

            // Iniciar pantalla y ADC
            Console.WriteLine("Iniciando Pantalla OLED y ADC de batería");
            Oled_bateria oledDisplay = new Oled_bateria(ADC_PIN, I2C_SCL, I2C_SDA);
            Thread.Sleep(1000);
            oledDisplay.DisplayText("Inicilizando", 2, 20);
            Thread.Sleep(200);
            oledDisplay.DisplayText("Espere.", 2, 20);
            Thread.Sleep(200);
            oledDisplay.DisplayText("Espere..", 2, 20);
            Thread.Sleep(200);
            oledDisplay.DisplayText("Espere...", 2, 20);

            // Objeto para conexión Wi-Fi
            WifiConnectionToNetwork WifiConexion = new WifiConnectionToNetwork(WIFI_CONFIG_FILE_NAME);

            // Iniciar la MicroSD para tener acceso a los archivos necesarios para el funcionamiento del servidor HTTP
            if (GestorSD.Montar(out string errorSD))
            {
                Console.WriteLine("MicroSD montada correctamente. Archivos listos.");
                // Cargamos la configuración Wi-Fi desde la SD
                WifiCfg = WifiConfig.LoadConfig(WIFI_CONFIG_FILE_NAME);
            }
            else
            {
                Console.WriteLine("CUIDADO: Fallo al montar MicroSD: " + errorSD);
                // Si la SD falla, inicializamos una config vacía para no romper el programa
                oledDisplay.DisplayText("CUIDADO: Fallo al montar MicroSD", 2, 20);
                WifiCfg = new WifiConfig();
            }

            // Se guarda la configuración Wifi por defecto al arrancar el programa

            WifiAdapter WifiSta = WifiAdapter.FindAllAdapters()[0];
            WifiSta.AvailableNetworksChanged += WifiConnectionToNetwork.WifiSta_AvailableNetworksChanged;

            oledDisplay.DisplayText("Conectando WiFi...", 2, 20);

            while (!WifiConnectionToNetwork.Connected)
            {
                try
                {
                    Console.WriteLine("Escaneo de redes...");
                    oledDisplay.DisplayText("Escaneando redes...", 2, 20);
                    WifiSta.ScanAsync();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al escanear: " + ex.Message);
                    oledDisplay.DisplayText("Error WiFi", 2, 20);
                }
                Thread.Sleep(10000);
            }
            Console.WriteLine("Conectado a la red WiFi correctamente.");
            oledDisplay.DisplayText("WiFi Conectado!", 2, 20);
            Thread.Sleep(2000);

            IPAddress ip = IPGlobalProperties.GetIPAddress();

            // Reintentar si la IP aún no está lista
            try
            {
                if (ip == null)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("Esperando dirección IP...");
                        oledDisplay.DisplayText("Obteniendo IP...", 2, 20);
                        Thread.Sleep(2000);
                        ip = IPGlobalProperties.GetIPAddress();
                    }
                }
                else
                {
                    Console.WriteLine("Dirección IP asignada: " + ip.ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener la dirección IP: " + ex.Message);
            }

            HttpListener Listener = new HttpListener("http"); // Crea un nuevo HttpListener para escuchar en el protocolo HTTP
            Listener.Start(); // Inicia la escucha en el puerto especificado ante posibles conexiones
            Console.WriteLine("Servidor HTTP iniciado. Esperando conexiones...");


            try
            {
                // Esto pausa el bucle hasta que alguien entra a la IP
                oledDisplay.DisplayText("Entrar a pagina http://" + ip.ToString() + "/", 2, 20);

                HttpListenerContext firstContext = Listener.GetContext();

                // Se atiende a tu navegador para mostrarle la página web
                HttpFunctions.HandleHttpRequest(firstContext, GestorSD, WifiCfg, WIFI_CONFIG_FILE_NAME, MqttCfg, MQTT_CONFIG_FILE_NAME, ModbusCfg, MODBUS_CONFIG_FILE_NAME);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error en el servidor web: " + ex.Message);
            }

            // Inicialización de Modbus
            Console.WriteLine("Iniciando configuración Modbus...");
            ModbusCfg = ModbusConfig.LoadConfig(MODBUS_CONFIG_FILE_NAME);
            ModbusManager = new ModbusDriver(ModbusCfg, TX, RX);

            if (ModbusManager.Initialize())
            {
                Console.WriteLine("Cliente Modbus completamente inicializado.");

                gpioController.Write(LED_MODBUS_PIN, PinValue.High); // Enciende LED Modbus
                oledDisplay.DisplayText("Modbus inicializado.", 2, 20);
                Thread.Sleep(1000);
            }
            else
            {
                Console.WriteLine("ADVERTENCIA: El cliente Modbus no se pudo inicializar.");

                gpioController.Write(LED_MODBUS_PIN, PinValue.Low);  //  LED apagado si falla
                oledDisplay.DisplayText("Modbus no iniciado", 2, 20);
                Thread.Sleep(1000);
            }

            // Inicialización de MQTT
            Console.WriteLine("Iniciando configuración MQTT...");
            oledDisplay.DisplayText("Iniciando configuracion MQTT...", 2, 20);
            MqttCfg = MqttConfig.LoadConfig(MQTT_CONFIG_FILE_NAME);
            MqttManager = new MqttDriver(MqttCfg);

            if (MqttManager.Initialize())
            {
                // Suscribirse al evento para recibir los comandos desde el Broker
                MqttManager.OnCommandReceived += MqttManager_OnCommandReceived;
                Console.WriteLine("Cliente MQTT completamente inicializado y suscrito a eventos.");


                gpioController.Write(LED_MQTT_PIN, PinValue.High); // Enciende LED MQTT
                oledDisplay.DisplayText("MQTT suscrito", 2, 20);

                // Inicialización de envío periódico de datos
                Thread mqttReportThread = new Thread(() => MqttReportingTask(MqttCfg.reportInterval * 1000));
                mqttReportThread.Start();
            }
            else
            {
                Console.WriteLine("ADVERTENCIA: El cliente MQTT no se pudo inicializar.");
                gpioController.Write(LED_MQTT_PIN, PinValue.Low); // LED apagado si falla
            }

            oledDisplay.ClearDisplay();

            Thread oledThread = new Thread(() =>
            {
                while (true)
                {
                    oledDisplay.UpdateDisplay();
                    Thread.Sleep(1000); // Actualiza la pantalla cada 1 segundo
                }
            });
            oledThread.Start();


            // Seguir atendiendo solicitudes de la página
            while (true)
            {
                try
                {
                    HttpListenerContext Context = Listener.GetContext();
                    HttpFunctions.HandleHttpRequest(Context, GestorSD, WifiCfg, WIFI_CONFIG_FILE_NAME, MqttCfg, MQTT_CONFIG_FILE_NAME, ModbusCfg, MODBUS_CONFIG_FILE_NAME);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error en el servidor web: " + ex.Message);
                }
            }
        }

        // Hilo para leer modbus y publicar por MQTT

        private static void MqttReportingTask(int delay)
        {
            Console.WriteLine("Hilo de reportes MQTT y lectura Modbus iniciado.");

            while (true)
            {
                try
                {
                    if (MqttManager != null && MqttManager.IsConnected && ModbusManager != null && ModbusCfg != null)
                    {
                        Report rep = new Report();
                        rep.DeviceID = (MqttCfg != null && MqttCfg.clientId != "") ? MqttCfg.clientId : "Gateway-DENT_ESP32";
                        rep.TimeStamp = DateTime.UtcNow.ToString("s");
                        rep.Registers = new ArrayList();

                        if (ModbusCfg.registers != null && ModbusCfg.registers.Length > 0)
                        {
                            byte slaveId = (byte)ModbusCfg.registers[0].slave;
                            ushort startAddress = 0;
                            ushort totalQuantity = 0;

                            // Calcular la cantidad de registros a leer según el tipo de dato
                            foreach (var reg in ModbusCfg.registers)
                            {
                                int cantidadRegistros = 1; // Por defecto INT16 o UINT16
                                string dt = reg.dataType;

                                if (dt.Contains("INT32") || dt.Contains("UINT32")) // 32 bits usa 2 registros
                                    cantidadRegistros = 2;

                                else if (dt.Contains("INT64") || dt.Contains("UINT64")) // 64 bits usa 4 registros
                                    cantidadRegistros = 4;

                                if ((reg.address + cantidadRegistros) > totalQuantity)
                                {
                                    totalQuantity = (ushort)(reg.address + cantidadRegistros);
                                }
                            }

                            short[] allData = ModbusManager.ReadRegisters(slaveId, startAddress, totalQuantity);

                            if (allData != null && allData.Length >= totalQuantity)
                            {
                                foreach (var reg in ModbusCfg.registers)
                                {
                                    int addr = reg.address;

                                    if (addr < allData.Length)
                                    {
                                        double finalValue = 0;
                                        string exact64BitValue = null; // Variable para atrapar el 64 bits sin perder precisión
                                        // Esto se hace porque si se entrega como double (variable finalValue), el número se recorta (porque double usa bits para exponente y signo)
                                        string dt = reg.dataType;

                                        try
                                        {
                                            if (dt.Contains("INT32") || dt.Contains("UINT32")) // Caso para registros de 32 bits
                                            {
                                                if ((addr + 1) < allData.Length)
                                                {
                                                    byte[] b0 = BitConverter.GetBytes(allData[addr]);
                                                    byte[] b1 = BitConverter.GetBytes(allData[addr + 1]);

                                                    byte[] byte4 = new byte[4];

                                                    if (dt.Contains("big endian"))
                                                    {
                                                        // ABCD
                                                        byte4[0] = b1[0]; byte4[1] = b1[1]; byte4[2] = b0[0]; byte4[3] = b0[1];
                                                    }
                                                    else // little endian
                                                    {
                                                        // DCBA: Invertimos palabras e invertimos bytes
                                                        byte4[0] = b0[1]; byte4[1] = b0[0]; byte4[2] = b1[1]; byte4[3] = b1[0];
                                                    }

                                                    if (dt.Contains("UINT32"))
                                                        finalValue = BitConverter.ToUInt32(byte4, 0);
                                                    else
                                                        finalValue = BitConverter.ToInt32(byte4, 0);
                                                }
                                            }
                                            else if (dt.Contains("INT64") || dt.Contains("UINT64")) // Caso para registros de 64 bits
                                            {
                                                if ((addr + 3) < allData.Length)
                                                {
                                                    byte[] b0 = BitConverter.GetBytes(allData[addr]);
                                                    byte[] b1 = BitConverter.GetBytes(allData[addr + 1]);
                                                    byte[] b2 = BitConverter.GetBytes(allData[addr + 2]);
                                                    byte[] b3 = BitConverter.GetBytes(allData[addr + 3]);

                                                    byte[] byte8 = new byte[8];

                                                    if (dt.Contains("big endian"))
                                                    {
                                                        // ABCDEFGH
                                                        byte8[0] = b3[0]; byte8[1] = b3[1]; byte8[2] = b2[0]; byte8[3] = b2[1];
                                                        byte8[4] = b1[0]; byte8[5] = b1[1]; byte8[6] = b0[0]; byte8[7] = b0[1];
                                                    }
                                                    else // little endian
                                                    {
                                                        // HGFEDCBA
                                                        byte8[0] = b0[1]; byte8[1] = b0[0]; byte8[2] = b1[1]; byte8[3] = b1[0];
                                                        byte8[4] = b2[1]; byte8[5] = b2[0]; byte8[6] = b3[1]; byte8[7] = b3[0];
                                                    }

                                                    // En 64 bits se convierte a string en vez de usar el double por el problema mencionado arriba
                                                    if (dt.Contains("UINT64"))
                                                        exact64BitValue = BitConverter.ToUInt64(byte8, 0).ToString();
                                                    else
                                                        exact64BitValue = BitConverter.ToInt64(byte8, 0).ToString();
                                                }
                                            }
                                            else if (dt == "UINT16")
                                            {
                                                // Convertir el short a unsigned (ushort)
                                                ushort uVal = (ushort)allData[addr];
                                                finalValue = uVal;
                                            }
                                            else // Por defecto INT16
                                            {
                                                finalValue = allData[addr];
                                            }
                                        }
                                        catch (Exception exConvert)
                                        {
                                            Console.WriteLine($"Error convirtiendo dato en addr {addr}: {exConvert.Message}");
                                        }

                                        RegValue val = new RegValue();
                                        val.Name = reg.name;

                                        if (exact64BitValue != null)
                                        {
                                            // Si es 64 bits, entregamos el dato puro e ignoramos la escala (porque al ser datos tan grandes, no podemos usar el double para decimales)
                                            val.Value = exact64BitValue + " " + reg.unit;
                                        }
                                        else
                                        {
                                            // Aplicamos la escala normal para los de 16 y 32 bits
                                            finalValue = finalValue * reg.scale;
                                            val.Value = finalValue.ToString("F2") + " " + reg.unit;
                                        }

                                        rep.Registers.Add(val);
                                    }

                                }
                            }
                            else
                            {
                                Console.WriteLine("[Modbus] Error: No se recibió respuesta de la lectura en bloque.");
                            }
                        }

                        if (rep.Registers.Count > 0)
                        {
                            string json = JsonConvert.SerializeObject(rep);
                            bool publicado = MqttManager.PublishData(json);

                            if (publicado)
                            {
                                Console.WriteLine($"[MQTT] Reporte publicado con {rep.Registers.Count} registros a las {GetTime()}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("[MQTT] Error en el hilo de reporte: " + ex.Message);
                }

                Thread.Sleep(delay);
            }
        }


        // Manejo de eventos MQTT (comandos que se envían desde MQTT)
        private static void MqttManager_OnCommandReceived(string topic, string jsonPayload)
        {
            try
            {
                Console.WriteLine($"\n[MQTT] Comando entrante en topic '{topic}'");
                Console.WriteLine($"[MQTT] Payload: {jsonPayload}");

                ModbusCommand cmd = (ModbusCommand)JsonConvert.DeserializeObject(jsonPayload, typeof(ModbusCommand));

                if (cmd != null && ModbusManager != null)
                {
                    Console.WriteLine($"[Modbus] Escribiendo al Esclavo {cmd.SlaveId}, Registro {cmd.Address}, Valor {cmd.Value}");

                    // Se busca el tipo de dato en la configuración
                    string dt = "INT16";
                    if (ModbusCfg != null && ModbusCfg.registers != null)
                    {
                        foreach (var reg in ModbusCfg.registers)
                        {
                            if (reg.address == cmd.Address)
                            {
                                dt = reg.dataType;
                                break;
                            }
                        }
                    }

                    bool success = false;

                    string valStr = cmd.Value.ToString();

                    // Si es mayor a 16 bits, se arma un arreglo y se usa el método WriteMultipleRegisters
                    if (dt == "FLOAT32" || dt.Contains("32") || dt.Contains("64"))
                    {
                        ushort[] regs = null;

                        if (dt == "FLOAT32")
                        {
                            float f = (float)Convert.ToDouble(valStr);
                            byte[] b = BitConverter.GetBytes(f);

                            ushort hw = (ushort)((b[3] << 8) | b[2]);
                            ushort lw = (ushort)((b[1] << 8) | b[0]);
                            regs = new ushort[] { hw, lw };
                        }
                        else if (dt.Contains("32"))
                        {
                            long lVal = 0;
                            try { lVal = Convert.ToInt64(valStr); }
                            catch { lVal = (long)Convert.ToDouble(valStr); }

                            uint v32 = (uint)lVal;
                            byte[] b = BitConverter.GetBytes(v32);

                            if (dt.Contains("little"))
                            {
                                // Little Endian (DCBA)
                                ushort v0 = (ushort)((b[0] << 8) | b[1]);
                                ushort v1 = (ushort)((b[2] << 8) | b[3]);
                                regs = new ushort[] { v0, v1 };
                            }
                            else
                            {
                                // Big Endian (ABCD)
                                ushort hw = (ushort)((b[3] << 8) | b[2]);
                                ushort lw = (ushort)((b[1] << 8) | b[0]);
                                regs = new ushort[] { hw, lw };
                            }
                        }
                        else if (dt.Contains("64"))
                        {
                            ulong v64 = 0;
                            try { v64 = (ulong)Convert.ToInt64(valStr); }
                            catch
                            {
                                try { v64 = Convert.ToUInt64(valStr); }
                                catch { v64 = (ulong)Convert.ToDouble(valStr); }
                            }

                            byte[] b = BitConverter.GetBytes(v64);

                            if (dt.Contains("little"))
                            {
                                // Little Endian (HGFEDCBA)
                                ushort v0 = (ushort)((b[0] << 8) | b[1]);
                                ushort v1 = (ushort)((b[2] << 8) | b[3]);
                                ushort v2 = (ushort)((b[4] << 8) | b[5]);
                                ushort v3 = (ushort)((b[6] << 8) | b[7]);
                                regs = new ushort[] { v0, v1, v2, v3 };
                            }
                            else
                            {
                                // Big Endian (ABCDEFGH)
                                ushort w3 = (ushort)((b[7] << 8) | b[6]);
                                ushort w2 = (ushort)((b[5] << 8) | b[4]);
                                ushort w1 = (ushort)((b[3] << 8) | b[2]);
                                ushort w0 = (ushort)((b[1] << 8) | b[0]);
                                regs = new ushort[] { w3, w2, w1, w0 };
                            }
                        }

                        if (regs != null)
                        {
                            success = ModbusManager.WriteMultipleRegisters(cmd.SlaveId, cmd.Address, regs);
                        }
                    }
                    else // Si es INT16 o UINT16, se usa el método WriteOnlyRegister
                    {
                        long lVal = 0;
                        try { lVal = Convert.ToInt64(valStr); }
                        catch { lVal = (long)Convert.ToDouble(valStr); }

                        short val16 = (short)lVal;
                        success = ModbusManager.WriteOnlyRegister(cmd.SlaveId, cmd.Address, val16);
                    }

                    if (success)
                    {
                        Console.WriteLine("[Modbus] Escritura exitosa.");
                    }
                    else
                    {
                        Console.WriteLine("[Modbus] Error al escribir el registro.");
                    }
                }
                else
                {
                    Console.WriteLine("[Modbus] Comando Modbus nulo o Driver no inicializado.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[MQTT] Error procesando el comando recibido: {ex.Message}");
            }
        }

        private static string GetTime()
        {
            string result = "[";
            result += DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
            result += "]";
            return result;
        }
    }
}